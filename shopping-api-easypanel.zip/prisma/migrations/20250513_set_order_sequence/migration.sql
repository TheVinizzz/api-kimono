-- Set the Order table sequence to start from 63582
SELECT setval('"Order_id_seq"', 63581, true); 